
    import { Composition } from "remotion";
import Component from "./Component";
import "./index.css";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="RemotionVideo"
        component={Component}
        durationInFrames={84 * 30}
        fps={30}
        width={1920}
        height={1080}
      />
    </>
  );
};
